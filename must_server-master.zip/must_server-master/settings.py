
# Mongo DB Cloud
MONGOURI="mongodb://admin:mustino@ds027489.mongolab.com:27489/mustino_dev1"
#server Port
PORT = 8080
# Status Codes
INACTIVE = 0
REGISTERED = 1
PAIRED = 2
CONNECT = 3


